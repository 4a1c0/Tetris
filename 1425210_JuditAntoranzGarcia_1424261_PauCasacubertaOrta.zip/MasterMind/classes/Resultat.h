#pragma once
#include <string>
#include <sstream>
#include "definicionsComunes.h"

using namespace std;

typedef enum { INCORRECTE, CORRECTE, POSICIO_INCORRECTA } Estats;

/**
* CLASS Resultat
* Respresenta un resultat de LONGITUD_COMBINACIO valors de tipus Estats
*/
class Resultat
{
public:
	Resultat();
	~Resultat();
	void netejar();
	void setPosicio(int, Estats);
	string mostrar();
	bool totCorrecte();
private:
	Estats m_resultat[LONGITUD_COMBINACIO];
};

