#pragma once
#include <string>
#include <sstream>
#include <ctime>
#include <cstdlib>
#include "definicionsComunes.h"
#include "Resultat.h"

using namespace std;

/**
* CLASS Combinacio
* Respresenta una combinacio de LONGITUD_COMBINACIO valors entre 1 i 6
*/
class Combinacio
{
public:
	Combinacio();
	~Combinacio();
	void esborrar();
	Resultat comparar(const Combinacio& comb1);
	void generar();
	bool introduirValors(unsigned short*);
	void llegir();
	std::string mostrar();
private:
	unsigned short m_combinacio[LONGITUD_COMBINACIO];
	bool conteValor(unsigned short);
};

