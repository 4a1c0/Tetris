#pragma once

#define SDL_MAIN_HANDLED

#include "keyboard.h"
#include "mouse.h"
#include "sprites.h"
#include "video.h"
#include "sound.h"
#include <cstring>
