#ifndef TETRISPROBA_H
#define TETRISPROBA_H


class TetrisProba
{
    public:
        TetrisProba();
        ~TetrisProba();
    protected:
    private:
};

#endif // TETRISPROBA_H
