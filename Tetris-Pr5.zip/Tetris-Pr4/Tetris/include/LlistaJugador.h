#ifndef LLISTAJUGADOR_H_INCLUDED
#define LLISTAJUGADOR_H_INCLUDED

class LlistaJugador
{
    public:
        LlistaJugador();
        ~LlistaJugador();
    private:
};


#endif // LLISTAJUGADOR_H_INCLUDED
