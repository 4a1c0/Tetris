#ifndef ITERADORNODEJUGADOR_H_INCLUDED
#define ITERADORNODEJUGADOR_H_INCLUDED
class IteradorNodeJugador
{
    public:
        IteradorNodeJugador();
        ~IteradorNodeJugador();
    private:
};


#endif // ITERADORNODEJUGADOR_H_INCLUDED
