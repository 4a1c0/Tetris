#ifndef NODEJUGADOR_H_INCLUDED
#define NODEJUGADOR_H_INCLUDED

class NodeJugador
{
    public:
        NodeJugador();
        ~NodeJugador();
    private:


};

#endif // NODEJUGADOR_H_INCLUDED
