#include "TetrisProba.h"

TetrisProba::TetrisProba()
{
    //ctor
}

TetrisProba::~TetrisProba()
{
    //dtor
}
