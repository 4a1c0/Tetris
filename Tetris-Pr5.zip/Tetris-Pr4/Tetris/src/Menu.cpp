
#include "Menu.h"


void menuPrincipal()
{
	system ("cls");

	printf("------ Menu Principal ------ \n");
	printf("\n");
	printf("1.- Jugar \n");
	printf("2.- Configurar \n");
	printf("3.- Millors Puntuacions \n");
	printf("4.- Sortir \n");
	printf("\n");
	printf("---------------------------- \n");

}


void menuNivellDificultat()
{
	system ("cls");

	printf("------ Menu Dificultat ------\n");
	printf("\n");
	printf("1.- Principiant\n");
	printf("2.- Mitja\n");
	printf("3.- Expert\n");
	printf("\n");
	printf("----------------------------\n");
}
