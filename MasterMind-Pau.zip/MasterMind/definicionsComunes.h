#pragma once
// Longitud de la combinaci�
const static int LONGITUD_COMBINACIO = 6;
// Valors posibles (entre 1 i 6)
const static int NUM_VALORS = 6;
//Max N intents
const int MAX_INTENTS = 14;