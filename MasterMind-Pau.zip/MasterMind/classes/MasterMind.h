#pragma once
#include <iostream>
using namespace std;

#include "Combinacio.h"
const int MAX_N_COMBINACIONS = 14;

/**
* CLASS Resultat
* Respresenta una partida del joc MasterMind
*/
class MasterMind
{
public:
	MasterMind();
	~MasterMind();
	void mostrarTauler();
	void iniciarJoc();
	bool demanarCombinacio();
	bool quedenIntents();
	void mostraCombinacioSecreta();
private:
	int m_darreraCombinacio;
	Combinacio m_combinacions[MAX_N_COMBINACIONS];
	Combinacio m_combinacioSecreta;
	Resultat m_resultats[MAX_N_COMBINACIONS];
};

