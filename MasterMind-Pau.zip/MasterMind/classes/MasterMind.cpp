#include "MasterMind.h"


MasterMind::MasterMind()
{
	m_darreraCombinacio = 0;
}


MasterMind::~MasterMind()
{
}


/**
* iniciarJoc
* Reinicia el joc netejant el tauler
*/
void MasterMind::iniciarJoc()
{
    m_combinacioSecreta.generar();
    
    system("cls");
    
    while ((quedenIntents()) && (!m_resultats[m_darreraCombinacio - 1].totCorrecte())) {
        
        demanarCombinacio();
        
        system("cls");
        
        mostrarTauler();
    }
    
    if (!quedenIntents()) {
        
        cout << endl << "\t** GAME OVER **" << endl;
        
        cout << "Has superat els " << MAX_INTENTS << " intents!" << endl;
        
        cout << "Aquesta era la Clau Secreta: " << endl;
        
        mostraCombinacioSecreta();
        

    }
        else if (m_resultats[m_darreraCombinacio - 1].totCorrecte())
        {
            cout << endl << "\t** L'HEM ENDIVINAT!!! **" << endl;
            
            cout << "Has completat el Joc en " << m_darreraCombinacio << " intents!" << endl << endl;
            

        }


}

/**
* mostrarTauler
* Mostra el tauler de la partida
*/
void MasterMind::mostrarTauler()
{
    for (int i = 0; i < m_darreraCombinacio; i++) {
        cout << "Intent " << i + 1 << ": " << m_combinacions[i].mostrar() << "___ " << m_resultats[i].mostrar() << endl;
    }

}

/**
* quedenIntents
* Retorna true si queden intents, false en cas contrari
* @return bool
*/
bool MasterMind::quedenIntents()
{
    bool intents = true;
    if (m_darreraCombinacio >= MAX_INTENTS) {
        intents = false;
    }
    return intents;
}
/**
* demanarCombinacio
* Demana al jugador una combinaci� de 6 valors. Si algun dels valors no es correcte torna demanar la combinaci�
* @return retorna true si la combinaci� entrada �s correcta
*/
bool MasterMind::demanarCombinacio()
{
	unsigned short valors[LONGITUD_COMBINACIO];
    bool correcte = false;

	do
	{
		cout << "ENTRA " << LONGITUD_COMBINACIO << " VALORS ENTRE 1 i " << NUM_VALORS << " DE SEPARATS AMB ESPAIS" << endl;
		for (int i = 0; i < LONGITUD_COMBINACIO; i++)
			cin >> valors[i];
		correcte = m_combinacions[m_darreraCombinacio].introduirValors(valors);
		if (!correcte)
		{
			cout << "Els valors introduits no son correctes" << endl;
			system("cls");
		}
	} while (!correcte);
	m_resultats[m_darreraCombinacio] = m_combinacioSecreta.comparar(m_combinacions[m_darreraCombinacio]);

	bool finalitzar = m_resultats[m_darreraCombinacio].totCorrecte();
	m_darreraCombinacio++;

	return finalitzar;
}

/**
* mostraCombinacioSecreta
* Mostra els valors de la combinaci� secreta
*/
void MasterMind::mostraCombinacioSecreta()
{
    cout << endl;
    
    cout << m_combinacioSecreta.mostrar() << endl;
    
    cout << endl;
    
}
