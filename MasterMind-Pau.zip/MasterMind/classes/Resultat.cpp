#include "Resultat.h"

/**
* Constructor
*/
Resultat::Resultat()
{
	netejar();
}

/**
* Destructor
*/
Resultat::~Resultat()
{
}

/**
* Esborra totes les posicions del resultat assignat el valor INCORRECTE a totes les posicions
* @return
*/
void Resultat::netejar()
{
	for (int i = 0; i < LONGITUD_COMBINACIO; i++)
		m_resultat[i] = INCORRECTE;
}

/**
* Assigna el valor estat a la posici� posicio
* @param posicio: Posici� en la que s'insereix l'estat
* @param estat: Valor inserit en la posici�
*/
void Resultat::setPosicio(int posicio, Estats estat)
{
	m_resultat[posicio] = estat;
}

/**
* Esborra totes les posicions del resultat assignat el valor INCORRECTE a totes les posicions
* @return string amb els car�cters que respresenten cada estat
*
*		- estat INCORRECTE
*		* estat CORRECTE
*		? POSICIO_INCORRECTE
*/
string Resultat::mostrar()
{
	stringstream resultat;
	for (int i = 0; i < LONGITUD_COMBINACIO; i++)
	{
		switch (m_resultat[i])
		{
		case INCORRECTE:
			resultat << "-";
			break;
		case CORRECTE:
			resultat << "*";
			break;
		case POSICIO_INCORRECTA:
			resultat << "?";
			break;
		}
		resultat << "  ";
	}

	return resultat.str();
}

/**
* totCorrecte
* Retorna true si totes les posicions del resultat tenen el valor CORRECTE o false en cas contrari
* @return bool
*/
bool Resultat::totCorrecte()
{
	bool correcte = true;
	int i = 0;
	while (i < LONGITUD_COMBINACIO && correcte)
	{
		correcte = (m_resultat[i] == CORRECTE);
		i++;
	}

	return correcte;
}
