#include "Combinacio.h"

/**
* Constructor
*/
Combinacio::Combinacio()
{
	esborrar();
}

/**
* Destructor
*/
Combinacio::~Combinacio()
{
}

/**
* esborrar
* Buida tots els valors de la combinaci� assignat el valor 0 a totes les posicions
*/
void Combinacio::esborrar()
{
    for (int i = 0; i < LONGITUD_COMBINACIO; i++) {
        m_combinacio[i] = 0;
    }
}

/**
* generar
* Genera una combinaci� aleat�ria
*/
void Combinacio::generar()
{
    srand((unsigned)time(NULL));
    
    
    for (int i = 0; i < LONGITUD_COMBINACIO; i++) {
        m_combinacio [i] = rand() % 6 + 1;
    }
    
}

/**
* introduirValors
* Buida tots els valors de la combinaci� assignat el valor 0 a totes les posicions
* @param valors: array amb els valors que es volen introduir a la combinaci�
* @return true si tots els valors s�n correctes (entre 1 i 6)
*/
bool Combinacio::introduirValors(unsigned short* valors)
{
    esborrar();
    
    int i = 0;
    bool correcte = true;
    while ((i < LONGITUD_COMBINACIO) && correcte) {
        if ((valors[i] < 1) || (valors[i] > 6))
            correcte = false;
        else
            m_combinacio[i] = valors[i];
        i++;
    }
    return correcte;
}

/**
* mostrar
* Retorna un string amb els valors de la combinaci�
* @return string
*/
string Combinacio::mostrar()
{
	stringstream combinacio;
	for (int i = 0; i < LONGITUD_COMBINACIO; i++)
	{
		combinacio << m_combinacio[i] << "  ";
	}

	return combinacio.str();
}

/**
* comparar
* Compara la combinaci� amb una altra i retorna un objecte Resultat
* @param combinacio: Combinaci� amb la que volem comparar
* @return objecte de la classe Resultat
*/
Resultat Combinacio::comparar(const Combinacio& combinacio)
{
	Resultat resultat;

	for (int i = 0; i < LONGITUD_COMBINACIO; i++)
	{
		if (m_combinacio[i] == combinacio.m_combinacio[i])
			resultat.setPosicio(i, CORRECTE);
		else if (conteValor(combinacio.m_combinacio[i]))
			resultat.setPosicio(i, POSICIO_INCORRECTA);
	}

	return resultat;
}

/**
* _conteValor
* Retorna true si la combinaci� cont� el valor que arriba per par�metre. Retorna false en cas contrari
* @param valor: valor que volem determinar si est� present en la combinaci�
* @return bool
*/
bool Combinacio::conteValor(unsigned short valor)
{
	bool trobat = false;
	int i = 0;
	while (i < LONGITUD_COMBINACIO && !trobat)
	{
		trobat = (m_combinacio[i] == valor);
		i++;
	}

	return trobat;
}
