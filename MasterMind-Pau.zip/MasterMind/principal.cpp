#include <iostream>
#include "MasterMind.h"

using namespace std;


void jugar();

int main()
{
	cout << "\t** BENVINGUT AL MASTERMIND **" << endl;
	char resposta;
	do {
		cout << "Tria una opcio: Jugar (J) - Sortir (S) ";
		cin >> resposta;
		resposta = toupper(resposta);
		if (resposta == 'J')
			jugar();
	} while (resposta != 'S');

	return 0;
}

/**
 * jugar
 */
void jugar()
{
    MasterMind partida;

    partida.iniciarJoc();
    

}
